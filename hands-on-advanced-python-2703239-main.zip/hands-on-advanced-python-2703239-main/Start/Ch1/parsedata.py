# Example file for Advanced Python: Hands On by Joe Marini
# Load and parse a JSON data file and determine some information about it


# TODO: open the sample weather data file and use the json module to load and parse it


# TODO: make sure the data loaded correctly by printing the length of the dataset

# TODO: let's also take a look at the first item in the data


# TODO: How many days of data do we have for each year?

